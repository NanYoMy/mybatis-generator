package com.gexin.oms.core.model;

import java.util.Date;

public class History {
    private Long id;

    private String message;

    private Date createTime;

    private Date updateTime;

    private String tableName = "history";

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message == null ? null : message.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public void setTableName(String tableName) {
        this.tableName=tableName;
    }

    public String getTableName() {
        return tableName;
    }
}